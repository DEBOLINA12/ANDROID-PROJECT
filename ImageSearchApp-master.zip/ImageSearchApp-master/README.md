# MVVM Image Search App with Architecture Components & Retrofit

Watch the course here: https://www.youtube.com/playlist?list=PLrnPJCHvNZuC_pEfFlZuTmjlY4T3DTtED

![thumbnail part 1](https://user-images.githubusercontent.com/52977034/116893176-f6906d00-ac30-11eb-9aa2-24583e6ca4e9.png)
